public class CustomBuilder {
    private  String id;
    private String name;
    private String address;

    public CustomBuilder(CustomgetBuild customgetBuild) {
        this.id = customgetBuild.id;
        this.name = customgetBuild.name;
        this.address = customgetBuild.address;
    }

    @Override
    public String toString() {
        return "CustomBuilder{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }
       static class   CustomgetBuild {
           private String id;
           private String name;
           private String address;

           public CustomgetBuild setAddress(String address) {
               this.address = address;
               return this;
           }

           public CustomgetBuild setName(String name) {
               this.name = name;
               return this;
           }

           public CustomgetBuild setId(String id) {
               this.id = id;
               return this;
           }

           public CustomBuilder build() {
               CustomBuilder customBuilder = new CustomBuilder(this);
               return customBuilder;
           }

           @Override
           public String toString() {
               return "CustomgetBuild{" +
                       "id='" + id + '\'' +
                       ", name='" + name + '\'' +
                       ", address='" + address + '\'' +
                       '}';
           }



       }
    public static CustomBuilder CustomgetBuild() {
        return new CustomBuilder();
    }
}
