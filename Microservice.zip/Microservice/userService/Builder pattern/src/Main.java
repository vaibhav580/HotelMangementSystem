public class Main {
    public static void main(String[] args) {
    CustomBuilder ownBuild=  CustomBuilder.CustomgetBuild().setId("123").setName("abc").setAddress("xyz").build();
    System.out.println(ownBuild);
        System.out.println("Hello, World!");
    }
}