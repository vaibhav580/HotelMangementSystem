package com.example.userService.userService.exception;

public class ResourceNotFoundException extends  RuntimeException{

    public  ResourceNotFoundException(){
        super("Resource not found on serever !!");
    }

    public ResourceNotFoundException(String message){
        super(message);
    }
}
