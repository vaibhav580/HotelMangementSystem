package com.example.userService.userService.payload;

import lombok.*;
import org.springframework.http.HttpStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ApiResponse {
    private boolean success;
    private String message;
    private HttpStatus status;

}
