package com.example.userService.userService.Service;

import com.example.userService.userService.entities.User;

import java.util.List;

public interface UserService {
    // create
    User saveUser(User user);

    // get all user
    List<User> getallUser();

    // get single user using user id
    User getUser(String userId);

}
