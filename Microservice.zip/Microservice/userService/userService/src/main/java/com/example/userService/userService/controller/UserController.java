package com.example.userService.userService.controller;

import com.example.userService.userService.Service.impl.UserServiceImpl;
import com.example.userService.userService.entities.User;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserServiceImpl userService;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user){
        User user1 = userService.saveUser(user);
      //  return ResponseEntity.ok(user);
        return new ResponseEntity<>(user1, HttpStatus.CREATED);
    }

    // get Single User
    @CircuitBreaker(name="RatingHotelBreaker", fallbackMethod = "ratingHotelFallBack")
    @GetMapping("/{userId}")
    public ResponseEntity<User> getSingleUser(@PathVariable String userId){
        User user = userService.getUser(userId);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    public ResponseEntity<User> ratingHotelFallBack(String userId, Exception ex){
        User user=User.builder()
                .email("abc@gamil.com").name("dummy")
                .about("this is the dummyb data because service is down")
                .userid("123")
                .build();
        return ResponseEntity.ok(user);
    }

    //get all user
    //Iterable
    @GetMapping
    public ResponseEntity<List<User>> getAllUser(){
        List<User> userList=userService.getallUser();
        return new ResponseEntity<>(userList, HttpStatus.OK);
    }
}
