package com.example.userService.userService.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jdk.jfr.MetadataDefinition;
import lombok.*;

import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Micro_user_Service")
@Builder
public class User {

    @Id
    private String userid;
    private String name;
    private  String email;
    private String about;
    @Transient
    private List<Rating> rating;
//    int p = 10;
//    10 = p
}
