package com.example.userService.userService.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.userService.userService.entities.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository  extends JpaRepository<User,String> {
}
