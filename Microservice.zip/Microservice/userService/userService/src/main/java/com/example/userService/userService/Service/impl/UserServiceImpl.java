package com.example.userService.userService.Service.impl;

import com.example.userService.userService.Repository.UserRepository;
import com.example.userService.userService.Service.UserService;
import com.example.userService.userService.entities.Hotel;
import com.example.userService.userService.entities.Rating;
import com.example.userService.userService.entities.User;
import com.example.userService.userService.exception.ResourceNotFoundException;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;


   // private Logger logger = (Logger) LoggerFactory.getLogger(UserServiceImpl.class);


    @Override
    public User saveUser(User user) {
       String randomUserId=UUID.randomUUID().toString();

        user.setUserid(randomUserId);
        //userCheck.setName1("NAmwee");

        //System.out.println("check "+userCheck.getName1());

        return userRepository.save(user);
    }

    @Override
    public List<User> getallUser() {
        return  userRepository.findAll();
    }

    @Override
    public User getUser(String userId) {
        User user=userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Resource are not found"));
        // http://localhost:8085/Rating/userId/17d9894b-4eb3-4282-8c5b-7fd447c5b0d2
         //ArrayList<Rating> obj=   restTemplate.getForObject("http://RatingService/Rating/userId/"+user.getUserid(), ArrayList.class);
         Rating[] obj=   restTemplate.getForObject("http://RATINGSERVICE/Rating/userId/"+user.getUserid(), Rating[].class);
         //logger.info("check "+ obj);

        List<Rating> ratingOfUser=Arrays.stream(obj).toList();
        List<Rating> ratingList = ratingOfUser.stream().map(rating -> {
            //api call to hotel service to get the hotel
            //http://localhost:8082/hotel
           ResponseEntity<Hotel> forEntity = restTemplate.getForEntity("http://HOTELSERVICE/hotel/" + rating.getHotelId(), Hotel.class);
           Hotel hotel = forEntity.getBody();
            //Hotel hotel = getHotelByRating(rating);
            rating.setHotel(hotel);
            return rating;
        }).collect(Collectors.toList());
         user.setRating(ratingList);

        return user;
    }

//    private Hotel getHotelByRating(Rating rating) {
//        Hotel hotelResponse = restTemplate.getForObject(
//                "http://HOTELSERVICE/hotel/" , Hotel.class);
//
//
//        return hotelResponse ;
//    }
}
