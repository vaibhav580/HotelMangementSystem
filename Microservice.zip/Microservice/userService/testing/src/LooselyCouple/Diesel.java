package LooselyCouple;

public class Diesel implements CarType {
    @Override
    public void show(){
        System.out.println(" Car is running on the Diesel");
    }
}
