package LooselyCouple;

public class Petrol implements CarType{

    @Override
    public void show(){

        System.out.println(" Car is running on the Petrol");
    }
}
