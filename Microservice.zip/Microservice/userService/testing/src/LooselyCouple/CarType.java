package LooselyCouple;

public interface CarType {
    public void show();
}
