package LooselyCouple;

public class LooselyMain {
    public static void main(String[] args) {
        Petrol petrol = new Petrol();
        Diesel diesel = new Diesel();
        car car = new car(diesel);
        car.move();
    }
}
