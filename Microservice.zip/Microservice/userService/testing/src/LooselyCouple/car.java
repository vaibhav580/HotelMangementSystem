package LooselyCouple;

public class car {
    CarType CarType;

    car(CarType CarType){
        this.CarType = CarType ;

    }
    public void move(){

        CarType.show();
    }
}
