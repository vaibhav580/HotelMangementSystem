package TightlyCouple;

public class car {
    Petrol petrol;
    car(){
        petrol = new Petrol();
    }
    public void move(){
        petrol.show();
    }
}
