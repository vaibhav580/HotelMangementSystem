package TightlyCouple;

public class TightlMain {
    public static void main(String[] args) {
        car car = new car();
        car.move();
    }
}
