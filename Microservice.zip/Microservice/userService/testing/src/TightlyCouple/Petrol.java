package TightlyCouple;

public class Petrol {
    public void show(){
        System.out.println(" Car is running on the Petrol");
    }
}
