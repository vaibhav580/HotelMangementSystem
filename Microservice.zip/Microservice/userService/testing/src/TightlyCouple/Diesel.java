package TightlyCouple;

public class Diesel {
    public void show(){
        System.out.println(" Car is running on the Diesel");
    }
}
