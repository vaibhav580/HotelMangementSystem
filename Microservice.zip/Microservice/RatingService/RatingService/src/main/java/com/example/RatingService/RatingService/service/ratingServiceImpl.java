package com.example.RatingService.RatingService.service;

import com.example.RatingService.RatingService.entities.Rating;
import com.example.RatingService.RatingService.repository.ratingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ratingServiceImpl implements ratingService{

    @Autowired
    private ratingRepository RatingRepository;
    @Override
    public Rating create(Rating rating) {
        return RatingRepository.save(rating) ;
    }

    @Override
    public List<Rating> getall() {
        return RatingRepository.findAll();
    }

    @Override
    public List<Rating> getRatingByUserId(String userId) {
        return RatingRepository.findByUserId(userId);
    }

    @Override
    public List<Rating> getRatingbyHotlelid(String hotelId) {
        return RatingRepository.findByHotelId(hotelId);
    }
}
