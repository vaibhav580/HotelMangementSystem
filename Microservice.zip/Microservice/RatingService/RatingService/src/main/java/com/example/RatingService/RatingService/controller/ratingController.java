package com.example.RatingService.RatingService.controller;

import com.example.RatingService.RatingService.entities.Rating;
import com.example.RatingService.RatingService.service.ratingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Rating")
public class ratingController {

    @Autowired
    private ratingService ratingSevice;

    // create
    @PostMapping("/hello")
    public ResponseEntity<Rating> create (@RequestBody Rating rating){
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingSevice.create(rating));
    }

    // get all

    @GetMapping

    public  ResponseEntity<List<Rating>> getRatings(){
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingSevice.getall());
    }

    @GetMapping("/userId/{userId}")

    public ResponseEntity<List<Rating>> getRatingByUserId(@PathVariable String userId){
        return  ResponseEntity.status(HttpStatus.FOUND).body(ratingSevice.getRatingByUserId(userId));
    }

    @GetMapping("/hotelId/{hotelId}")

    public ResponseEntity<List<Rating>> getRatingByHotelId(@PathVariable String hotelId){
        return  ResponseEntity.status(HttpStatus.FOUND).body(ratingSevice.getRatingbyHotlelid(hotelId));
    }


}
