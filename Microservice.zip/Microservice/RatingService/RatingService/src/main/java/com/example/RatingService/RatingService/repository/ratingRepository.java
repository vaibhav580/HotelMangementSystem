package com.example.RatingService.RatingService.repository;

import com.example.RatingService.RatingService.entities.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface ratingRepository extends JpaRepository<Rating,Integer> {

    // custom finder method
    List<Rating> findByUserId(String userId);
    List<Rating>findByHotelId(String hotelId);
}
