package com.example.RatingService.RatingService.service;

import com.example.RatingService.RatingService.entities.Rating;

import java.util.List;

public interface ratingService {

    // create
    Rating create(Rating rating);

    // get all rating
    List<Rating> getall();

    // get by ID

    List<Rating> getRatingByUserId(String userId);

    //get all by hotel id
    List<Rating> getRatingbyHotlelid(String hotelId);
}
