package com.example.HotelService.Hotel_Service.Service.impl;

import com.example.HotelService.Hotel_Service.Service.HotelService;
import com.example.HotelService.Hotel_Service.entities.Hotel;
import com.example.HotelService.Hotel_Service.exception.ResourceNotFoundException;
import com.example.HotelService.Hotel_Service.repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class HotelServiceImpl implements HotelService {
    @Autowired
    private HotelRepository hotelRepository;
    @Override
    public Hotel create(Hotel hotel) {
         String id=UUID.randomUUID().toString();
         hotel.setId(id);
       //  hotelRepository.save(hotel);
        return hotelRepository.save(hotel);
    }

    @Override
    public List<Hotel> getall() {

        return hotelRepository.findAll();
    }

    @Override
    public Hotel get(String id) {
        return hotelRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("hotel with given id is not found"));
    }
}
