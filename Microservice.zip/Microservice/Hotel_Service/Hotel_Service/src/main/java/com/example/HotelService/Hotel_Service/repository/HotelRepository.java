package com.example.HotelService.Hotel_Service.repository;

import com.example.HotelService.Hotel_Service.entities.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, String> {
}
