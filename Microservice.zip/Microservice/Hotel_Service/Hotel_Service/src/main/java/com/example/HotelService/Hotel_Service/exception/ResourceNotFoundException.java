package com.example.HotelService.Hotel_Service.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
    public ResourceNotFoundException () {
        super("Resource are not found plz check");
    }
}
