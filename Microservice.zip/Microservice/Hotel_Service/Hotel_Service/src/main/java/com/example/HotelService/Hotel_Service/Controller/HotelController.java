package com.example.HotelService.Hotel_Service.Controller;

import com.example.HotelService.Hotel_Service.Service.HotelService;
import com.example.HotelService.Hotel_Service.Service.impl.HotelServiceImpl;
import com.example.HotelService.Hotel_Service.entities.Hotel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/hotel")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    @PostMapping
    public ResponseEntity<Hotel> createHotel( @RequestBody Hotel hotel){
        return ResponseEntity.ok(hotelService.create(hotel));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Hotel> getHotelbyID( @PathVariable String id){
        return ResponseEntity.ok(hotelService.get(id));
    }
    @GetMapping
    public ResponseEntity<List<Hotel>> getAllHotel(){
        return ResponseEntity.ok(hotelService.getall());

    }

}
