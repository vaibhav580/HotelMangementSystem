package com.example.HotelService.Hotel_Service.exception;

import com.example.HotelService.Hotel_Service.exception.payload.ApiResponse;
import org.hibernate.annotations.NotFound;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler()
    public ResponseEntity<Map<String,String>> handlerResponseEntityException(ResourceNotFoundException ex){
        String message = ex.getMessage();
//        ApiResponse response=ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
        HashMap<String,String> response = new HashMap<>();
        response.put("message",message);
        response.put("success","true");
        response.put("status",HttpStatus.NOT_FOUND.toString());
        return ResponseEntity.ok().body(response);

//        return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
    }
}
