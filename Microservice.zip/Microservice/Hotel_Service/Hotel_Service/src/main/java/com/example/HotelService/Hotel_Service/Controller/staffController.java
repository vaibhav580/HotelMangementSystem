package com.example.HotelService.Hotel_Service.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/staff")
public class staffController {
    @GetMapping
    public ResponseEntity<List<String>> getStaffName(){
        List<String> staffName= new ArrayList<>();
        staffName.add("ram");
        staffName.add("getta");
        return ResponseEntity.status(HttpStatus.OK).body(staffName);
    }
}
