package com.example.HotelService.Hotel_Service.Service;

import com.example.HotelService.Hotel_Service.entities.Hotel;

import java.util.List;

public interface HotelService {
    Hotel create(Hotel hotel);
    List<Hotel> getall();
    Hotel get(String id);

}
